Project Title:

Custom WordPress Theme Development (Internship Task 2)

Tools Used:
WordPress
XAMPP (Local server)
PHP
HTML / CSS
VS Code

Theme Features:
Custom header and footer using WordPress functions
Homepage with latest posts using WordPress Loop
Featured images and excerpts
Single post page with full content
Blog archive page
Sidebar with widgets + custom ad block
Navigation menu using wp_nav_menu()
Responsive layout with 3-card homepage design

Installation Steps:
Install WordPress on local server (XAMPP)
Copy theme folder to:
wp-content/themes/
Activate theme from WordPress dashboard
Set menu from Appearance → Menus → primary(set to)
Add widgets to sidebar

Key Features:
Custom homepage hero section
Card-based blog layout
Dynamic sidebar
Clean navigation menu
Fully functional WordPress theme structure

👨‍💻 WordPress Developer:

Komal Shehzadi