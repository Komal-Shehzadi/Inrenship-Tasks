<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action(
    'wp_ajax_mup_hello',
    'mup_ajax_hello'
);

add_action(
    'wp_ajax_nopriv_mup_hello',
    'mup_ajax_hello'
);

function mup_ajax_hello() {

    if (
        !isset($_POST['nonce']) ||
        !wp_verify_nonce($_POST['nonce'], 'mup_nonce')
    ) {

        wp_send_json_error(
            array(
                'message' => 'Invalid security token.'
            )
        );
    }

    wp_send_json_success(
        array(
            'message' => 'Hello Visitor! AJAX feature is working successfully.'
        )
    );
}