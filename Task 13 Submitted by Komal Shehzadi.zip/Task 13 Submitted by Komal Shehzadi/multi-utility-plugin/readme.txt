Plugin Name: Multi Utility Plugin

Purpose:
A custom WordPress utility plugin that demonstrates admin and frontend functionality.

Admin Features:
- Custom Dashboard Page
- Banner Control
- Footer Message Control
- Feature Toggle Options
- Statistics Panel

Frontend Features:
- Website Banner
- Footer Message
- Utility Shortcode
- AJAX Interaction Button

Shortcodes:
[utility_message]

[mup_ajax_demo]

Hooks Used:
- add_action()
- add_filter()
- wp_ajax

Security:
- Sanitization
- Escaped Output
- Nonce Verification

Installation:
1. Copy plugin folder to wp-content/plugins
2. Activate plugin
3. Open Utility Plugin menu
4. Configure settings

Author:
Komal Shehzadi
Version:
2.0