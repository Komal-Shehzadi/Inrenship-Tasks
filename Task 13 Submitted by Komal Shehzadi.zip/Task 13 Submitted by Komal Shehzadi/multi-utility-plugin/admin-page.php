<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">

<h1>Multi Utility Plugin Dashboard</h1>

<div style="
display:flex;
gap:15px;
margin:20px 0;
flex-wrap:wrap;
">

<div style="
background:#fff;
padding:20px;
border:1px solid #ddd;
min-width:180px;">
📢 Banner System
</div>

<div style="
background:#fff;
padding:20px;
border:1px solid #ddd;
min-width:180px;">
🔗 Shortcodes
</div>

<div style="
background:#fff;
padding:20px;
border:1px solid #ddd;
min-width:180px;">
⚡ AJAX Feature
</div>

</div>

<form method="post" action="options.php">

<?php settings_fields('mup_settings_group'); ?>

<table class="form-table">

<tr>
<th>Enable Banner</th>
<td>
<input
type="checkbox"
name="mup_enable_banner"
value="1"
<?php checked(get_option('mup_enable_banner'),1); ?>>
</td>
</tr>

<tr>
<th>Banner Message</th>
<td>
<input
type="text"
name="mup_banner_message"
value="<?php echo esc_attr(get_option('mup_banner_message')); ?>"
class="regular-text">
</td>
</tr>

<tr>
<th>Enable Footer Message</th>
<td>
<input
type="checkbox"
name="mup_enable_footer"
value="1"
<?php checked(get_option('mup_enable_footer'),1); ?>>
</td>
</tr>

<tr>
<th>Footer Message</th>
<td>
<input
type="text"
name="mup_footer_message"
value="<?php echo esc_attr(get_option('mup_footer_message')); ?>"
class="regular-text">
</td>
</tr>

</table>

<?php submit_button('Save Settings'); ?>

</form>

<hr>

<h2>Plugin Statistics</h2>

<table class="widefat">

<tr>
<td>Total Visits</td>
<td><?php echo intval(get_option('mup_visit_count',0)); ?></td>
</tr>

<tr>
<td>Banner Status</td>
<td>
<?php echo get_option('mup_enable_banner') ? 'Enabled' : 'Disabled'; ?>
</td>
</tr>

<tr>
<td>Footer Status</td>
<td>
<?php echo get_option('mup_enable_footer') ? 'Enabled' : 'Disabled'; ?>
</td>
</tr>

</table>

<hr>

<h2>Available Shortcodes</h2>

<div style="
background:#fff;
padding:15px;
border:1px solid #ddd;">

<p>
<strong>[utility_message]</strong><br>
Displays a utility message box.
</p>

<p>
<strong>[mup_ajax_demo]</strong><br>
Displays AJAX interaction button.
</p>

</div>

</div>